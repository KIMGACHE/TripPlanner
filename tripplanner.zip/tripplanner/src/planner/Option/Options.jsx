import {useState, useEffect} from 'react';

const Options = (props) => {
    // 각 체크박스의 checked상태 정의
    const [food, setFood] = useState(true);
    const [accom, setAccom] = useState(true);
    const [place, setPlace] = useState(true);

    // select의 상태 정의
    const [area, setArea] = useState(null);

    // 체크박스 전체를 check상태로 설정
    const viewAll = () => {
        setFood(true);
        setAccom(true);
        setPlace(true);
    }
    // 각각의 체크박스를 눌렀을 때 checked의 상태 설정
    const viewFood = () => {setFood(!food)}
    const viewAccom = () => {setAccom(!accom)}
    const viewPlace = () => {setPlace(!place)}

    // select의 지역좌표를 area에 설정
    const handleSelect = (e) => {
        const data = e.target.value;
        if(data!=null) {
            setArea(data.split(','));
        }
    };

    useEffect(()=>{
        props.OptionData([{"food":food,"accom":accom,"place":place}])
    },[food,accom,place])

    useEffect(()=>{
        props.AreaData(area);
    },area)

    const areaCoordinate = [
                    {value:[0,0], name:"도시를 선택하세요"},
                    {value:[126.9779692,37.566535], name: "서울"},    // 서울
                    {value:[129.05562775,35.1379222], name: "부산"},  // 부산
                    {value:[126.7052062, 37.4562557], name: "인천"},  // 인천
                    {value:[128.601445, 35.8714354], name: "대구"},   // 대구
                    {value:[127.3845475, 36.3504119], name: "대전"},  // 대전
                    {value:[126.8526012, 35.1595454], name: "광주"},  // 광주
                    {value:[129.3113596, 35.5383773], name: "울산"},  // 울산
                    {value:[127.5183, 37.4138], name: "경기"},        // 경기도
                    {value:[128.18161,37.142803], name: "충북"},      // 충청북도
                    {value:[127.1516,36.8075], name: "충남"},         // 충청남도
                    {value:[126.991, 34.8679], name: "전남"},         // 전남
                    {value:[127.153, 35.7175], name: "전북"},         // 전북
                    {value:[128.8889, 36.4919], name: "경북"},        // 경북
                    {value:[128.2132, 35.4606], name: "경남"},        // 경남
                    {value:[128.1555, 37.8228], name: "강원도"},      // 강원도
                    {value:[126.794586, 33.532237], name: "제주도"},  // 제주도
                ]

    return (
        <>
            <input
                type="button"
                name="all"
                id="all"
                onClick={viewAll}
                value="전체"
            />
            
            <label>식당</label>
            <input
                type="checkbox"
                name="food"
                id="food"
                onChange={viewFood}
                checked={food}
            />

            <label>숙소</label>
            <input
                type="checkbox"
                name="accom"
                id="accom"
                onChange={viewAccom}
                checked={accom}
            />

            <label>관광지</label>
            <input
                type="checkbox"
                name="place"
                id="place"
                checked={place}
                onChange={viewPlace}
            />

            <select onChange={handleSelect} value={area!=null&&area} >
                {areaCoordinate.map((item,index)=>{
                    return (
                        <option value={item.value} key={index}>
                            {item.name}
                        </option>
                    );
                })}
            </select>
        </>
    );
}

export default Options;