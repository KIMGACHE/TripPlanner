import {useState, useEffect} from 'react';
import {Link} from 'react-router-dom';
import Options from '../Option/Options';
import SideBar from '../SideBar/SideBar';
import Map from '../Map/Map';

const MakePlanner = () => {
    const [optionState, setOptionState] = useState();
    const [areaState, setAreaState] = useState();

    const handleOption = (data) => {
        setOptionState(data);
    }

    const handleArea = (data) => {
        setAreaState(data)
    }

    useEffect(()=>{
        console.log("MakePlanner's areaState : ", areaState);
    },[optionState,areaState])

    return (
        <div className='planner' >
            <div className='plannerHeader' >
                <Options OptionData={handleOption} AreaData={handleArea} />
            </div>
            <div className='plannerBody' >
                <SideBar/>
                <Map OptionData={optionState} AreaData={areaState} />
            </div>
            
        </div>
    )
}

export default MakePlanner;